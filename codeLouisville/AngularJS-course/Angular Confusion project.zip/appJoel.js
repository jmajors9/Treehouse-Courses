angular.module('treehouseCourse', [])
  .controller('stageCtrl', function ($scope, $http){
  $scope.people = [];
  
  $http.get('people.json')
  .sucess(funtion(respose){
    $scope.people = respone;
   })
    .error(funtion (err) {
       alert(err);
     });
});